import React, { Profiler, useState } from 'react';
import Map from './map/map.component';
import './index.scss';
import state from '../../index.state';
import {observer} from 'mobx-react'


// state.tiktok();
// state.tiktok2();
// state.tiktok3()
const Index = observer(() => {
    return (
        <>
            <div className='mapwrap'>
                <Map />
            </div>
            {/* <h2>
                {state.tik.a.b}
            </h2>
            <h2>
                {state.tik2.a.b}
            </h2> */}
        </>
    )
})
export default Index;