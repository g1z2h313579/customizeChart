import React from 'react';
import CurrentPage from '../config/router';
import { Layout, Breadcrumb } from 'antd';
import SiderBar from './components/SiderBar/SiderBar';
import Head from './components/head/head';
import Foot from './components/foot/foot';
import Bread from './components/bread/bread';
import state from '../index.state';
import './index.scss'
const { Content } = Layout;


const Entry = () => {
    return (
        <Layout style={{ minHeight: '100vh' }}>
            <SiderBar />
            <Layout>
                <Head />
                <Content className = 'contentwrap'>
                    <Bread/>
                    <div className="bodyContainer">
                        <CurrentPage />
                    </div>
                </Content>
                <Foot />
            </Layout>
        </Layout>

    )
}


export default Entry