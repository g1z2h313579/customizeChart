import React from 'react';
import Chart from './chartone/chart.component'


const Index = () => {
    return (
        <div className = 'chartOne'>
            <Chart  />
        </div>
    )
}


export default Index