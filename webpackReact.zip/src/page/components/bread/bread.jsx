import React from 'react';
import { Breadcrumb } from 'antd';


const Bread = () => {
    return (
        <Breadcrumb>
            <Breadcrumb.Item>User</Breadcrumb.Item>
            <Breadcrumb.Item>Bill</Breadcrumb.Item>
        </Breadcrumb>
    )
}

export default Bread;