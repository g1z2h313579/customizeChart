import React,{lazy,Suspense} from 'react'
import {Route, Switch,Redirect} from 'react-router-dom';

const PartOne = lazy(() => import('../page/threeJS/line/index'));

const BoxGeometry = lazy(() => import('../page/threeJS/BoxGeometry/index'))
const BoxGeometry2 = lazy(() => import('../page/threeJS/BoxGeometry2/index'))
const ballGeometry = lazy(() => import('../page/threeJS/ballGeometry/index'));
const pointLearn = lazy(() => import('../page/threeJS/pointLearn/index'));
const modalObject = lazy(() => import('../page/threeJS/modalObject/index'));
const Light = lazy(() => import('../page/threeJS/light/index'));
const Curve = lazy(() => import('../page/threeJS/curve/index'));
const Curve2 = lazy(() => import('../page/threeJS/curve2/index'));

const intervalStack = lazy(() => import('../page/chart/intervalStack/index'));
const Home = lazy(() => import('../page/map/index'));

const PartTwo = lazy(() => import('../page/partTwo/index'));
const AAA = lazy(() => import('../page/qichacha/index'));





class Routes extends React.Component{


    render(){
        return (
            <Suspense fallback = {<div>loading.....</div>}>
                <Switch>
                    <Redirect from = '/' exact to = '/map' />
                    <Route exact strict component = {Home} path = '/map' />
                    <Route exact strict component = {PartOne} path = "/line" />
                    <Route exact strict component = {BoxGeometry} path = "/boxGeometryAnimate" />
                    <Route exact strict component = {BoxGeometry2} path = "/boxGeometryMouseControl" />
                    <Route exact strict component = {ballGeometry} path = "/ballGeometry" />
                    <Route exact strict component = {pointLearn} path = "/pointLearn" />
                    <Route exact strict component = {modalObject} path = "/modalObject" />
                    <Route exact strict component = {Light} path = "/light" />
                    <Route exact strict component = {Curve} path = "/curve" />
                    <Route exact strict component = {Curve2} path = "/curve2" />




                    <Route exact strict component = {PartTwo} path = "/react" />
                    

                    <Route exact strict component = {intervalStack} path = "/intervalStack" />
                </Switch>
            </Suspense>
            
        )
    }
}


export default Routes